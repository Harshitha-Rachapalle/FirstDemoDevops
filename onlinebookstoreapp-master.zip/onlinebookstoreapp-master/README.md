# OnlineBookStore Website Using  Java
<br>
<span style="color:blue">**This Website is built for following purpose:-**</span>
- For Selling books online.
- Maintaining books selling history.
- Adding and managing books.
- User Friendly.
- For Implemention of Generic Servlets in Java.
- This is a Mini-project developed using Java, Jdbc, And Generic Servlets.

<span style="color:blue">**Admin Have Following Access for this online store site:**</span>
- Add New Books.
- View Books Available.
- Remove Books.
- Increase Books Amount.

<span style="color:blue">**Users Have Following Access for this online store site:-**</span>
- Create New Account or Register.
- Login.
- View Available Books.
- Select Books to Buy.
- Select Books Quantity.
- Buy Books.
- Get Payment Receipt.

### Technologies used:-
1. Front-End Development:
- Html.
- Css.
- Javascript.

2. Back-End Development
- Java [JDK 8+]
- JDBC
- Servlet
- MySQL
- Apache Maven

3. Database used.
- MySql

### ==== Software And Tools Required ====
- MySQL
- Eclipse [Enterprise Edition]
- Java [JDK 8+]
- Tomcat v8.0+
- Apache Maven

Note:- This is a Sample Project, So we have used only Generic Servlet and not taken care for Security.

### =============== Dummy Database Initialization =====================

STEP 1: Open MySQL Command Prompt or MySQL Workbench

STEP 2: Login to the administrator user as : ```mysql -u <username> -p``` (Enter Password if asked)

STEP 3 :Copy paste the following MySql Commands:
```MySQL
create database onlinebookstore;

use onlinebookstore;

create table books(barcode varchar(100) primary key, name varchar(100), author varchar(100), price int, quantity int);

create table users(username varchar(100) primary key,password varchar(100), firstname varchar(100),
    lastname varchar(100),address text, phone varchar(100),mailid varchar(100),usertype int);

insert into books values('10101','C','James',500,5);
insert into books values('10102','Java','Scott ',150,13);
insert into books values('10103','Database','Charles',124,360);
insert into users values('User','Password','First','User','My Home','42502216225','User@gmail.com',2);
insert into users values('Admin','Admin','Mr.','Admin','Haldia WB','9584552224521','admin@gmail.com',1);
insert into users values('mgmg','mgmg','Mgmg','u','high','1236547089','mgmg@gmail.com',2);

commit;
```

### ======== Importing and Running The Project Through Eclipse EE ===========

Step 0: Open Eclipse Enterprise Edition. [Install, if not already installed.]

Step 1: Click On File > Import > Git > Projects From Git > Clone Uri  > Paste The Repository Url as: ```https://github.com/drilldevops/onlinebookstore.git```

Step 2: Go inside ```OnlineBookStore > constants > IDatabase.java``` and update the value of USER_NAME and PASSWORD according to your installed mysql admin user credentials

Step 3: Install or Run Tomcat Serevr and deploy the application war file(Copy from target/) and place it in tomcat webapps folder

Step 4: Bring up Tomcat server.

Step 6: Check Running The Site At <a href="http://localhost:8083/onlinebookstore/">http://localhost:8080/onlinebookstore/</a>

Step 7: Default Username And Password For Admin Is "Admin" And "Admin"

Step 8: Default Username And Password For User Is "MgMg" And "MgMg".


#### "Suggestions and project Improvements are Invited!"

<bold>Thanks a lot</bold><br/>
